// ─────────────────────────────────────────────────────────────
// La Maison — Stripe Checkout Session creator
// Vercel Serverless Function  /api/create-checkout
//
// Environment variables required (set in Vercel dashboard):
//   STRIPE_SECRET_KEY   — your Stripe secret key (sk_live_... or sk_test_...)
// ─────────────────────────────────────────────────────────────

const Stripe = require('stripe');

module.exports = async function handler(req, res) {
  // CORS headers (allow your deployed domain in production)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const stripeKey = process.env.STRIPE_SECRET_KEY;
  if (!stripeKey) {
    return res.status(500).json({ error: 'Stripe key not configured.' });
  }

  const stripe = Stripe(stripeKey);

  const {
    lineItems,
    deliveryLabel,
    deliveryPrice,
    customerEmail,
    customerName,
    successUrl,
    cancelUrl,
  } = req.body;

  // ── Validate ──
  if (!lineItems || !Array.isArray(lineItems) || lineItems.length === 0) {
    return res.status(400).json({ error: 'No items in cart.' });
  }
  if (!successUrl || !cancelUrl) {
    return res.status(400).json({ error: 'Missing success/cancel URLs.' });
  }

  // ── Build Stripe line_items ──
  const stripeLineItems = lineItems.map(item => ({
    price_data: {
      currency: 'usd',
      product_data: {
        name: item.name,
        description: item.restoName || 'La Maison Boutique',
        // You can add images here once products are in Stripe:
        // images: [item.imageUrl],
        metadata: { restoName: item.restoName || '' },
      },
      unit_amount: Math.round(item.price * 100), // Stripe expects cents
    },
    quantity: item.quantity,
  }));

  // ── Add delivery as a separate line item (if any cost) ──
  if (deliveryPrice && deliveryPrice > 0) {
    stripeLineItems.push({
      price_data: {
        currency: 'usd',
        product_data: {
          name: deliveryLabel || 'Delivery',
          description: 'Shipping & handling',
        },
        unit_amount: Math.round(deliveryPrice * 100),
      },
      quantity: 1,
    });
  }

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: stripeLineItems,

      // Pre-fill customer email if provided
      ...(customerEmail ? { customer_email: customerEmail } : {}),

      // Collect shipping address on Stripe's page
      shipping_address_collection: {
        allowed_countries: ['US', 'CA', 'GB', 'FR', 'DE', 'AU', 'JP'],
      },

      // Enable common payment methods + wallets
      payment_method_types: ['card', 'link'],

      // Automatic tax (optional — requires Stripe Tax to be enabled)
      // automatic_tax: { enabled: true },

      // Metadata for your records
      metadata: {
        customerName: customerName || '',
        source: 'la-maison-boutique',
      },

      success_url: successUrl,
      cancel_url: cancelUrl,

      // Allow customers to adjust qty on Stripe's page
      // adjustable_quantity: { enabled: true, minimum: 1 },
    });

    return res.status(200).json({ url: session.url });

  } catch (err) {
    console.error('Stripe error:', err.message);
    return res.status(500).json({ error: err.message });
  }
};
