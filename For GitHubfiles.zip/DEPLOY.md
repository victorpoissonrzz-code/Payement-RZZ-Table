# La Maison — Deployment Guide
## Stripe + Vercel setup in 10 minutes

---

## Files in this package

```
/
├── index_final.html          ← The complete website (all pages)
├── api/
│   └── create-checkout.js    ← Vercel serverless function (Stripe)
├── vercel.json               ← Vercel routing config
├── package.json              ← Node dependencies
└── DEPLOY.md                 ← This guide
```

---

## Step 1 — Get your Stripe keys

1. Log in at **https://dashboard.stripe.com**
2. Go to **Developers → API keys**
3. Copy your **Secret key**:
   - For testing: `sk_test_...`
   - For production: `sk_live_...`

> ⚠️ Never put your secret key in HTML or any public file.  
> It lives only in Vercel's environment variables (step 3).

---

## Step 2 — Push to GitHub

Create a new GitHub repository and push these files:

```bash
git init
git add .
git commit -m "La Maison boutique — initial deploy"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/la-maison.git
git push -u origin main
```

---

## Step 3 — Deploy on Vercel

1. Go to **https://vercel.com** → **Add New Project**
2. Import your GitHub repository
3. Vercel will auto-detect the config from `vercel.json`
4. Before clicking Deploy, go to **Environment Variables** and add:

   | Name | Value |
   |------|-------|
   | `STRIPE_SECRET_KEY` | `sk_test_...` or `sk_live_...` |

5. Click **Deploy** — done in ~60 seconds

Your site will be live at `https://your-project.vercel.app`

---

## Step 4 — Test in Stripe test mode

Use these test card numbers (with any future expiry + any CVC):

| Card | Number |
|------|--------|
| Visa (success) | `4242 4242 4242 4242` |
| Mastercard | `5555 5555 5555 4444` |
| Payment declined | `4000 0000 0000 0002` |
| Requires 3D Secure | `4000 0025 0000 3155` |

Apple Pay and Google Pay work automatically in test mode on Stripe's hosted page.

---

## Step 5 — Go live

1. In your Stripe dashboard, complete the account activation
2. In Vercel, update the environment variable:
   - Change `STRIPE_SECRET_KEY` from `sk_test_...` to `sk_live_...`
3. Redeploy (or Vercel auto-deploys on next git push)

---

## How the payment flow works

```
User clicks "Pay securely with Stripe"
    ↓
Browser sends cart to /api/create-checkout (your Vercel function)
    ↓
Function creates a Stripe Checkout Session with your secret key
    ↓
Stripe returns a hosted checkout URL
    ↓
Browser redirects to Stripe's secure payment page
(Stripe handles card entry, 3DS, Apple Pay, Google Pay)
    ↓
After payment: Stripe redirects to ?order=success
    ↓
La Maison shows the confirmation page, cart is cleared
```

---

## Optional enhancements

### Add product images to Stripe
In `api/create-checkout.js`, uncomment and populate:
```js
images: ['https://your-cdn.com/jacket.jpg'],
```

### Enable Stripe Tax (automatic tax calculation)
In `api/create-checkout.js`, uncomment:
```js
automatic_tax: { enabled: true },
```
Then configure your tax settings in the Stripe dashboard.

### Webhooks (recommended for production)
For reliable order fulfillment, set up a Stripe webhook to receive
`checkout.session.completed` events. This is how you trigger emails,
update inventory, etc. See: https://stripe.com/docs/webhooks

### Custom domain
In Vercel → Project Settings → Domains → Add your domain.
Update DNS at your registrar to point to Vercel.

---

## Support

- Stripe docs: https://stripe.com/docs/checkout/quickstart
- Vercel docs: https://vercel.com/docs
- Stripe test cards: https://stripe.com/docs/testing
